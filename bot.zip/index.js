const Discord = require('discord.js');
const bot = new Discord.Client();
const token = "NjUyMTQ3MDQ0ODk4NzAxMzMy.Xekb4w.H3QXDrvA3Jo_u7-0qKl7jA3Xjpk";

bot.on('message', function(message){
    if(message.channel.name == "helpdesk"){
        const accountSid = 'AC516e47ef0131426ceabf33593eda012f';
        const authToken = '7181d4905fe15408da9020b7c0dee85e';
        const client = require('twilio')(accountSid, authToken);

        client.messages
            .create({
             // mediaUrl: ['https://images.unsplash.com/photo-1545093149-618ce3bcf49d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=668&q=80'],
                from: 'whatsapp:+14155238886',
                body: message.content,
                to: 'whatsapp:+31622959802'
        })
        .then(message => console.log(message.sid));
    }
});
bot.login(token)


